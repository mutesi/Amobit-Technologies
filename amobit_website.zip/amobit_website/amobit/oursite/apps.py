from django.apps import AppConfig


class OursiteConfig(AppConfig):
    name = 'oursite'
